
<?php $__env->startSection('title'); ?>
Settings
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <!-- Earnings (Monthly) Card Example -->
    <div class="col-lg-12">
      <div class="card border-left-dark shadow h-100 py-2">
        <div class="card-body col-lg-12">
          <?php if(Session::has('success')): ?>
          <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-12">
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
          <br>
          <?php endif; ?>
          <?php if(Session::has('error')): ?>
          <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-12">
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
          <br>
          <?php endif; ?>
          <div class="row">
            <div class="col-lg-12 text-right">
              <a class="btn-dark btn" href="<?php echo e(route('home')); ?>"><i class="fas fa-arrow-left"></i> Back To Dashboard</a>
            </div>
          </div>
          <br>
          <div class="row no-gutters align-items-center">
            <div class="col-lg-10 offset-lg-1 col-md-12">
            <form method="POST" action="<?php echo e(route('settings.update')); ?>">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">currency</label>
                <input name="currency" type="text" class="form-control" value="<?php echo e($settings->currency); ?>">
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">api_secret_key</label>
                <input name="api_secret_key" type="text" class="form-control" value="<?php echo e($settings->api_secret_key); ?>">
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">min_to_withdraw</label>
                <input name="min_to_withdraw" type="text" class="form-control" value="<?php echo e($settings->min_to_withdraw); ?>">
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">conversion_rate</label>
                <input name="conversion_rate" type="text" class="form-control" value="<?php echo e($settings->conversion_rate); ?>">
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">hint_coins</label>
                <input name="hint_coins" type="text" class="form-control" value="<?php echo e($settings->hint_coins); ?>">
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">referral_register_points</label>
                <input name="referral_register_points" type="text" class="form-control" value="<?php echo e($settings->referral_register_points); ?>">
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">video_ad_coins</label>
                <input name="video_ad_coins" type="text" class="form-control" value="<?php echo e($settings->video_ad_coins); ?>">
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">daily_reward</label>
                <input name="daily_reward" type="text" class="form-control" value="<?php echo e($settings->daily_reward); ?>">
              </div>
              <hr>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">App Language</label>
                <select name="lang" class="form-control">
                  <option <?php if($settings->lang=="en"): ?> selected <?php endif; ?> value="en">English</option>
                  <option <?php if($settings->lang=="es"): ?> selected <?php endif; ?> value="es">Spanish</option>
                  <option <?php if($settings->lang=="tr"): ?> selected <?php endif; ?> value="tr">Turkish</option>
                  <option <?php if($settings->lang=="hi"): ?> selected <?php endif; ?> value="hi">Hindi</option>
                </select>
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">Completed Question Option</label>
                <select name="completed_option" class="form-control">
                  <option <?php if($settings->completed_option=="yes"): ?> selected <?php endif; ?> value="yes">Yes</option>
                  <option <?php if($settings->completed_option=="no"): ?> selected <?php endif; ?> value="no">No</option>
                </select>
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">Fifty Fifty (50/50) Option</label>
                <select name="fifty_fifty" class="form-control">
                  <option <?php if($settings->fifty_fifty=="yes"): ?> selected <?php endif; ?> value="yes">Yes</option>
                  <option <?php if($settings->fifty_fifty=="no"): ?> selected <?php endif; ?> value="no">No</option>
                </select>
              </div>
              <div class="form-group">
                <label style="font-weight:bold !important; color: black !important;">One user per device Option</label>
                <select name="one_device" class="form-control">
                  <option <?php if($settings->one_device=="yes"): ?> selected <?php endif; ?> value="yes">Yes</option>
                  <option <?php if($settings->one_device=="no"): ?> selected <?php endif; ?> value="no">No</option>
                </select>
              </div>
              <button type="submit" class="btn btn-block btn-success">Update</button>
            </form>
            </div>
            <div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\UltimateQuiz\resources\views/settings.blade.php ENDPATH**/ ?>