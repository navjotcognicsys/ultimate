
<?php $__env->startSection('title'); ?>
Players
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <!-- Earnings (Monthly) Card Example -->
    <div class="col-lg-12">
      <div class="card border-left-dark shadow h-100 py-2">
        <div class="card-body col-lg-12">
          <?php if(Session::has('success')): ?>
          <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-12">
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
          <br>
          <?php endif; ?>
          <?php if(Session::has('error')): ?>
          <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-12">
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
          <br>
          <?php endif; ?>
          <div class="row">
            <div class="col-lg-6">
              <a class="btn-success btn btn-block" href="#" data-toggle="modal" data-target="#addModal"><i class="fas fa-plus"></i> Add New Player</a>
            </div>
            <div class="col-lg-6 text-right">
              <a class="btn-dark btn" href="<?php echo e(route('home')); ?>"><i class="fas fa-arrow-left"></i> Back To Dashboard</a>
            </div>
          </div>
          <br>
          <!-- Add Player Modal-->
          <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Add New Player</h5>
                  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form method="POST" action="<?php echo e(route('players.new')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group text-left">
                      <label>Player Username</label>
                      <input name="username" type="text" class="form-control" placeholder="Enter player username">
                    </div>
                    <div class="form-group text-left">
                      <label>Player Email</label>
                      <input name="email_or_phone" type="email" class="form-control" placeholder="Enter player email">
                    </div>
                    <div class="form-group text-left">
                      <label>Player Password</label>
                      <input name="password" type="password" class="form-control" placeholder="Enter password">
                    </div>
                    <div class="form-group text-left">
                      <label>Player Score</label>
                      <input name="actual_score" type="text" class="form-control" placeholder="Enter player score">
                    </div>
                    <div class="form-group text-left">
                      <label>Player Coins</label>
                      <input name="coins" type="text" class="form-control" placeholder="Enter player coins">
                    </div>
                    <div class="form-group text-left">
                      <label>Player Facebook Link</label>
                      <input name="facebook" type="text" class="form-control" placeholder="Enter player facebook link">
                    </div>
                    <div class="form-group text-left">
                      <label>Player Twitter Link</label>
                      <input name="twitter" type="text" class="form-control" placeholder="Enter player twitter link">
                    </div>
                    <div class="form-group text-left">
                      <label>Player Instagram Link</label>
                      <input name="instagram" type="text" class="form-control" placeholder="Enter player instagram link">
                    </div>
                    <div class="form-group text-left">
                      <label>Player Avatar</label>
                      <input name="image_url" accept="image/x-png,image/jpeg" type="file" class="form-control">
                    </div>
                    <div class="text-right">
                      <button class="btn btn-sm btn-success" type="submit">Save Player</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="row no-gutters align-items-center table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th class="align-middle text-center" scope="col">Avatar</th>
                  <th class="align-middle text-center" scope="col">Username</th>
                  <th class="align-middle text-center" scope="col">Email/Phone</th>
                  <th class="align-middle text-center" scope="col">Register Method</th>
                  <th class="align-middle text-center" scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="align-middle text-center"><img src="<?php echo e($player->image_url); ?>" height="40px" width="40px" class="rounded-circle"></td>
                  <td class="align-middle text-center"><?php echo e($player->username); ?></td>
                  <td class="align-middle text-center"><?php echo e($player->email_or_phone); ?></td>
                  <td class="align-middle text-center">
                    <?php if($player->login_method == "facebook"): ?>
                    <img src="<?php echo e(asset('img/facebook.png')); ?>" height="20px">
                    <?php endif; ?>
                    <?php if($player->login_method == "google"): ?>
                    <img src="<?php echo e(asset('img/google.png')); ?>" height="20px">
                    <?php endif; ?>
                    <?php if($player->login_method == "admin"): ?>
                    <span style="padding: 5px 10px 5px 10px !important; font-size: 12px !important;" class="badge badge-pill badge-danger">By Admin</span>
                    <?php endif; ?>
                    <?php if($player->login_method == "otp"): ?>
                    <img src="<?php echo e(asset('img/otp.png')); ?>" height="20px">
                    <?php endif; ?>
                    <?php if($player->login_method == "email"): ?>
                    <img src="<?php echo e(asset('img/mail.png')); ?>" height="20px">
                    <?php endif; ?>
                  </td>
                  <td class="align-middle text-center">
                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('players.edit', ['id'=>$player->id])); ?>"><i class="fas fa-edit"></i></a>
                    <!-- Edit Player Modal-->
                    <a class="btn btn-sm btn-danger" href="" data-toggle="modal" data-target="#deleteModal<?php echo e($player->id); ?>"><i class="fas fa-trash-alt"></i></a>
                  </td>
                  <!-- Delete Modal-->
                  <div class="modal fade" id="deleteModal<?php echo e($player->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Delete Player</h5>
                          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">Are You Sure To Delete This Player ?</div>
                        <div class="modal-footer">
                          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                          <a class="btn btn-info" href="<?php echo e(route('players.delete', ['id'=>$player->id])); ?>">Delete</a>

                        </div>
                      </div>
                    </div>
                  </div>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e($players->links()); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\UltimateQuiz\resources\views\players.blade.php ENDPATH**/ ?>