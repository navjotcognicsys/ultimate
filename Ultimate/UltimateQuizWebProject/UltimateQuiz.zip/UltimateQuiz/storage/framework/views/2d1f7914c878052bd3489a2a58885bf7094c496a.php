
<?php $__env->startSection('title'); ?>
Image Questions Categories
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <!-- Earnings (Monthly) Card Example -->
    <div class="col-lg-12">
      <div class="card border-left-dark shadow h-100 py-2">
        <div class="card-body col-lg-12">
          <?php if(Session::has('success')): ?>
          <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-12">
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
          <br>
          <?php endif; ?>
          <?php if(Session::has('error')): ?>
          <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-12">
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
          <br>
          <?php endif; ?>
          <div class="row">
            <div class="col-lg-12 text-right">
              <a class="btn-dark btn" href="<?php echo e(route('home')); ?>"><i class="fas fa-arrow-left"></i> Back To Dashboard</a>
            </div>
          </div>
          <br>

          <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-sm-6">
            <div class="card" style="margin: 5px;">
              <img style="height: 190px !important;"  src="<?php echo e(asset('uploads/categories/'.$category->category_img)); ?>" class="card-img-top" alt="<?php echo e($category->category_name); ?>">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($category->category_name); ?></h5>
                <a href="<?php echo e(route('imagequestions.subcategories', ['category'=>$category->id])); ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> Choose A Subcategory</a>
              </div>
            </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <br>
          <div>
              <?php echo e($categories->links()); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\UltimateQuiz\resources\views/imagequestions_categories.blade.php ENDPATH**/ ?>