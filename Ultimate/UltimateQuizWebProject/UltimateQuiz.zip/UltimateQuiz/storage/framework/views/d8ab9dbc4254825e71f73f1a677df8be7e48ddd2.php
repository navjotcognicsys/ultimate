<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->

    <ul class="navbar-nav bg-gradient-info sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a style="height:150px !important;" class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('home')); ?>">
        <div class="sidebar-brand-icon">
          <i class="fas fa-user-cog"></i>
        </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item <?php if(\Request::is('/')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span class="sidebar-title">Dashboard</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      <!-- Nav Item - Admins -->
      <li class="nav-item <?php if(\Request::is('admins')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('admins')); ?>">
          <i class="fas fa-fw fa-user-lock"></i>
          <span class="sidebar-title">Admins</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      <!-- Nav Item - Players -->
      <li class="nav-item <?php if(\Request::is('players/*') || \Request::is('players')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('players')); ?>">
          <i class="fas fa-fw fa-users"></i>
          <span class="sidebar-title">Players</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      <!-- Nav Item - Categories -->
      <li class="nav-item <?php if(\Request::is('categories/*') || \Request::is('categories')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('categories')); ?>">
          <i class="fas fa-fw fa-bars"></i>
          <span class="sidebar-title">Categories</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      <!-- Nav Item - Subcategories -->
      <li class="nav-item <?php if(\Request::is('subcategories/*') || \Request::is('subcategories')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('subcategories')); ?>">
          <i class="fas fa-fw fa-database"></i>
          <span class="sidebar-title">Subcategories</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      <!-- Nav Item - Quizzes -->
      <li class="nav-item <?php if(\Request::is('quizzes/*') || \Request::is('quizzes')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('quizzes')); ?>">
          <i class="fas fa-fw fa-cubes"></i>
          <span class="sidebar-title">Quizzes</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      <!-- Nav Item - Text Questions -->
      <li class="nav-item <?php if(\Request::is('textquestions/*') || \Request::is('textquestions')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('textquestions.categories')); ?>">
          <i class="fas fa-text-width fa-fw"></i>
          <span class="sidebar-title">Text Questions</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      <!-- Nav Item - Text Questions -->
      <li class="nav-item <?php if(\Request::is('imagequestions/*') || \Request::is('imagequestions')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('imagequestions.categories')); ?>">
          <i class="fas fa-fw fa-images"></i>
          <span class="sidebar-title">Image Questions</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      <!-- Nav Item - Text Questions -->
      <li class="nav-item <?php if(\Request::is('audioquestions/*') || \Request::is('audioquestions')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('audioquestions.categories')); ?>">
          <i class="fas fa-fw fa-volume-up"></i>
          <span class="sidebar-title">Audio Questions</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
       <!-- Nav Item - Daily Quiz -->
      <li class="nav-item <?php if(\Request::is('dailyquiz/*') || \Request::is('dailyquiz')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('dailyquiz')); ?>">
          <i class="fas fa-hourglass-half"></i>
          <span class="sidebar-title">Daily Quiz</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item <?php if(\Request::is('withdraws/*')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('withdraws')); ?>">
          <i class="fas fa-money-bill-wave"></i>
          <span class="sidebar-title">Withdraws</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item <?php if(\Request::is('paymentmethods/*')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('paymentmethods')); ?>">
          <i class="fab fa-cc-visa"></i>
          <span class="sidebar-title">Payment Methods</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item <?php if(\Request::is('ads/*')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('ads')); ?>">
          <i class="fab fa-buysellads"></i>
          <span class="sidebar-title">Ads Management</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item <?php if(\Request::is('settings/*')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('settings')); ?>">
          <i class="fas fa-cogs"></i>
          <span class="sidebar-title">Settings</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->
<?php /**PATH C:\wamp64\www\UltimateQuiz\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>