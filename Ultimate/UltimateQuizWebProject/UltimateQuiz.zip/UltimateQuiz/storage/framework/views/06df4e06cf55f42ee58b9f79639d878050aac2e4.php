<!-- Footer -->
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>All Rights Reserved &copy; Created By : <a href="https://codecanyon.net/user/todocode" target="_blank">TodoCode</a></span>
    </div>
  </div>
</footer>
<!-- End of Footer -->
</div>
<!-- End of Content Wrapper -->
</div>
<!-- End of Page Wrapper -->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
<i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
  <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
    <span aria-hidden="true">×</span>
    </button>
  </div>
  <div class="modal-body">Are You Sure To Logout ?</div>
  <div class="modal-footer">
    <button class="btn btn-secondary" type="button" data-dismiss="modal">Back</button>
    <a class="btn btn-info" href="<?php echo e(route('home')); ?>"
      onclick="event.preventDefault();
    document.getElementById('logout-form').submit();"> Logout </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
      <?php echo csrf_field(); ?>
    </form>
  </div>
</div>
</div>
</div>
<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('js/sb-admin-2.min.js')); ?>"></script>
<!-- Page level plugins -->
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-filestyle.js')); ?>"> </script>
<?php echo $__env->yieldContent('ckeditor'); ?>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script src="http://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script>
CKEDITOR.replace( 'add-article' );
</script>
</body>
</html>
<?php /**PATH C:\wamp64\www\UltimateQuiz\resources\views/partials/footer.blade.php ENDPATH**/ ?>