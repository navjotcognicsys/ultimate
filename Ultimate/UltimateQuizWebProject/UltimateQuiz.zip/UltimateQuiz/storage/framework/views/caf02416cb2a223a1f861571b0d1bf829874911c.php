<!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
            <li class="nav-item no-arrow">
              <a class="nav-link" href="" data-toggle="modal" data-target="#logoutModal">
                <span class="navbar-linked mr-1 d-none d-lg-inline text-dark small">
                  <i class="fas fa-sign-out-alt"></i>Logout</span>
                <img class="img-profile rounded-circle" src="<?php echo e(asset('img/admin.png')); ?>">
              </a>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->
<?php /**PATH C:\wamp64\www\UltimateQuiz\resources\views/partials/navbar.blade.php ENDPATH**/ ?>